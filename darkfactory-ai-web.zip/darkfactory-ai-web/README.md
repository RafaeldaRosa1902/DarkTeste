# DarkFactory AI | Versão Web

Implantação online via Render Blueprint em `render.yaml`. Veja [docs/WEB_DEPLOY.md](docs/WEB_DEPLOY.md).

Esta versão hospeda o fluxo editorial demonstrativo, sem token Supabase manual. Renderização real não está habilitada em modo demo.
