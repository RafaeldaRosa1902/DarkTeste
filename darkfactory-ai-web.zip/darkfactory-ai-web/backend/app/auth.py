import os
import jwt
from jwt import PyJWKClient
from fastapi import Header,HTTPException
_jwks=None

def authenticated_user(authorization:str|None=Header(None),x_demo_user:str|None=Header(None)):
 global _jwks
 if os.getenv('DEMO_MODE','false').lower()=='true':return x_demo_user or 'demo-user'
 if not authorization or not authorization.startswith('Bearer '):raise HTTPException(401,'Bearer token obrigatório')
 url=os.getenv('SUPABASE_URL','').rstrip('/')
 if not url:raise HTTPException(503,'SUPABASE_URL ausente')
 try:
  token=authorization[7:]
  if _jwks is None:_jwks=PyJWKClient(url+'/auth/v1/.well-known/jwks.json')
  key=_jwks.get_signing_key_from_jwt(token).key
  payload=jwt.decode(token,key,algorithms=['RS256','ES256'],audience='authenticated',options={'require':['exp','sub']})
  return payload['sub']
 except Exception as exc:raise HTTPException(401,'JWT inválido') from exc
