import os
from sqlalchemy import create_engine, Column, String, Integer, Text, Float, ForeignKey, UniqueConstraint, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
URL=os.getenv("DATABASE_URL","sqlite:////tmp/darkfactory.db")
if URL.startswith("postgres://"):
 URL="postgresql+psycopg://"+URL[len("postgres://"):]
elif URL.startswith("postgresql://"):
 URL="postgresql+psycopg://"+URL[len("postgresql://"):]
engine=create_engine(URL,connect_args={"check_same_thread":False} if URL.startswith("sqlite") else {})
Session=sessionmaker(bind=engine,expire_on_commit=False)
Base=declarative_base()
class User(Base):
 __tablename__='users'
 id=Column(String,primary_key=True)
 balance=Column(Integer,default=100,nullable=False)
class Channel(Base):
 __tablename__='channels'
 id=Column(String,primary_key=True);user_id=Column(String,index=True);name=Column(String);niche=Column(String);language=Column(String,default='pt-BR');region=Column(String,default='BR');template=Column(String,default='facts')
class Idea(Base):
 __tablename__='ideas'
 id=Column(String,primary_key=True);user_id=Column(String,index=True);channel_id=Column(String);title=Column(String);angle=Column(Text);status=Column(String,default='pending')
class Script(Base):
 __tablename__='scripts'
 id=Column(String,primary_key=True);user_id=Column(String,index=True);idea_id=Column(String);body=Column(Text);status=Column(String,default='draft');originality=Column(Float,default=1.0)
class Job(Base):
 __tablename__='jobs'
 id=Column(String,primary_key=True);user_id=Column(String,index=True);script_id=Column(String);status=Column(String,default='queued');error=Column(Text);video_path=Column(String);cost=Column(Integer,default=10);fps=Column(Integer,default=30);final_approved_at=Column(DateTime(timezone=True))
class Ledger(Base):
 __tablename__='ledger'
 id=Column(String,primary_key=True);user_id=Column(String,index=True);job_id=Column(String);kind=Column(String);amount=Column(Integer);key=Column(String,unique=True)
class Idempotency(Base):
 __tablename__='idempotency'
 key=Column(String,primary_key=True);user_id=Column(String);resource_id=Column(String)
if URL.startswith('sqlite:'):
 Base.metadata.create_all(engine)

# Compatibilidade com bancos SQLite locais criados antes da aprovação final.
if URL.startswith('sqlite:'):
 from sqlalchemy import inspect, text
 if 'final_approved_at' not in {c['name'] for c in inspect(engine).get_columns('jobs')}:
  with engine.begin() as connection:
   connection.execute(text('ALTER TABLE jobs ADD COLUMN final_approved_at DATETIME'))
