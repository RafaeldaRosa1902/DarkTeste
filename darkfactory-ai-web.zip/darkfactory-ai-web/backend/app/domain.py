import re,unicodedata
STATES=['queued','tts','transcribing','fetching_media','rendering','uploading','completed','failed','cancelled']
TRANSITIONS={'queued':{'tts','failed','cancelled'},'tts':{'transcribing','failed'},'transcribing':{'fetching_media','failed'},'fetching_media':{'rendering','failed'},'rendering':{'uploading','failed'},'uploading':{'completed','failed'}}
def normalize(s):
 s=unicodedata.normalize('NFKD',s.lower());return re.findall(r'\w+', ''.join(c for c in s if not unicodedata.combining(c)))
def ngrams(s,n=4):
 t=normalize(s);return set(tuple(t[i:i+n]) for i in range(max(0,len(t)-n+1)))
def originality(text,sources):
 a=ngrams(text)
 if not a:return 0.0
 return max(0.0,1-max((len(a & ngrams(s))/len(a) for s in sources),default=0))
def group_captions(words,max_words=4):
 result=[]
 for i in range(0,len(words),max_words):result.append(words[i:i+max_words])
 return result
