import os
from fastapi import FastAPI,HTTPException,Depends,Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel,Field
from .db import Session,Channel,Idea,Script,Job,User,Ledger
from .services import uid,ensure_user,create_job
from .providers import ideas as research_ideas,script as write_script,TEMPLATES
from .domain import originality
app=FastAPI(title='DarkFactory AI',version='0.1.0')
app.add_middleware(CORSMiddleware,allow_origins=os.getenv('CORS_ORIGINS','http://localhost:3000').split(','),allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
from .auth import authenticated_user as auth
class ChannelIn(BaseModel):
 name:str;niche:str;language:str='pt-BR';region:str='BR';template:str='facts'
class ResearchIn(BaseModel):
 signals:list[str]=Field(default_factory=list)
class ScriptIn(BaseModel):
 body:str
class RenderIn(BaseModel):
 fps:int=30
@app.get('/health')
def health():return {'ok':True}
@app.get('/v1/templates')
def templates():return TEMPLATES
@app.get('/v1/channels')
def channels(user=Depends(auth)):
 with Session() as db:return [dict(id=x.id,name=x.name,niche=x.niche,template=x.template) for x in db.query(Channel).filter_by(user_id=user).all()]
@app.post('/v1/channels')
def add_channel(data:ChannelIn,user=Depends(auth)):
 if data.template not in TEMPLATES:raise HTTPException(422,'Molde inválido')
 with Session.begin() as db:
  ensure_user(db,user);c=Channel(id=uid(),user_id=user,**data.model_dump());db.add(c);return {'id':c.id}
@app.post('/v1/channels/{channel_id}/research')
def research(channel_id:str,data:ResearchIn,user=Depends(auth)):
 with Session.begin() as db:
  c=db.get(Channel,channel_id)
  if not c or c.user_id!=user:raise HTTPException(404)
  result=[]
  for item in research_ideas(c.niche,c.region,c.language,data.signals):
   i=Idea(id=uid(),user_id=user,channel_id=channel_id,**item);db.add(i);result.append({'id':i.id,**item,'status':'pending'})
  return result
@app.get('/v1/channels/{channel_id}/ideas')
def list_ideas(channel_id:str,user=Depends(auth)):
 with Session() as db:
  c=db.get(Channel,channel_id)
  if not c or c.user_id!=user:raise HTTPException(404)
  return [dict(id=x.id,title=x.title,angle=x.angle,status=x.status) for x in db.query(Idea).filter_by(channel_id=channel_id,user_id=user).all()]
@app.post('/v1/ideas/{idea_id}/approve')
@app.post('/v1/ideas/{idea_id}/reject')
def decide_idea(idea_id:str,request:__import__('fastapi').Request,user=Depends(auth)):
 decision=request.url.path.rsplit('/',1)[-1]
 with Session.begin() as db:
  i=db.get(Idea,idea_id)
  if not i or i.user_id!=user:raise HTTPException(404)
  if i.status!='pending':raise HTTPException(409,'Ideia já decidida')
  i.status='approved' if decision=='approve' else 'rejected';return {'status':i.status}
@app.post('/v1/ideas/{idea_id}/script')
def generate_script(idea_id:str,user=Depends(auth)):
 with Session.begin() as db:
  i=db.get(Idea,idea_id)
  if not i or i.user_id!=user:raise HTTPException(404)
  if i.status!='approved':raise HTTPException(409,'Aprovação da ideia obrigatória')
  existing=db.query(Script).filter_by(idea_id=idea_id,user_id=user).first()
  if existing:return {'id':existing.id,'body':existing.body,'originality':existing.originality}
  c=db.get(Channel,i.channel_id);body=write_script(i.title,i.angle,c.template)
  score=originality(body,[i.title,i.angle]);attempt=0
  while score<0.85 and attempt<1:
   body=write_script(i.title,'Nova abordagem original, não reutilize frases do tema.',c.template);score=originality(body,[i.title,i.angle]);attempt+=1
  if score<0.85:raise HTTPException(422,'Originalidade insuficiente; geração recusada')
  s=Script(id=uid(),user_id=user,idea_id=i.id,body=body,originality=score);db.add(s);return {'id':s.id,'body':body,'originality':score}
@app.get('/v1/scripts/{script_id}')
def get_script(script_id:str,user=Depends(auth)):
 with Session() as db:
  s=db.get(Script,script_id)
  if not s or s.user_id!=user:raise HTTPException(404)
  return {'id':s.id,'body':s.body,'status':s.status,'originality':s.originality}
@app.put('/v1/scripts/{script_id}')
def edit_script(script_id:str,data:ScriptIn,user=Depends(auth)):
 with Session.begin() as db:
  s=db.get(Script,script_id)
  if not s or s.user_id!=user:raise HTTPException(404)
  if s.status!='draft':raise HTTPException(409)
  s.body=data.body;s.originality=originality(data.body,[]);return {'status':s.status}
@app.post('/v1/scripts/{script_id}/approve')
def approve_script(script_id:str,user=Depends(auth)):
 with Session.begin() as db:
  s=db.get(Script,script_id)
  if not s or s.user_id!=user:raise HTTPException(404)
  if s.status!='draft':raise HTTPException(409)
  if s.originality<0.85:raise HTTPException(422,'Originalidade insuficiente')
  s.status='approved';return {'status':s.status}
@app.post('/v1/scripts/{script_id}/render')
def render(script_id:str,data:RenderIn,idempotency_key:str|None=Header(None),user=Depends(auth)):
 if data.fps not in (30,60):raise HTTPException(422,'FPS inválido')
 if not idempotency_key:raise HTTPException(400,'Idempotency-Key obrigatório')
 with Session() as db:
  s=db.get(Script,script_id)
  if not s or s.user_id!=user:raise HTTPException(404)
  if s.status!='approved':raise HTTPException(409,'Roteiro não aprovado')
 try:job_id,created=create_job(user,script_id,user+':'+idempotency_key,data.fps)
 except ValueError as e:raise HTTPException(409,str(e))
 if created:
  from .worker import produce
  produce.delay(job_id)
 return {'id':job_id,'created':created}
@app.get('/v1/jobs/{job_id}')
def get_job(job_id:str,user=Depends(auth)):
 with Session() as db:
  j=db.get(Job,job_id)
  if not j or j.user_id!=user:raise HTTPException(404)
  return {'id':j.id,'status':j.status,'error':j.error,'has_video':bool(j.video_path)}
@app.post('/v1/jobs/{job_id}/approve')
def approve_video(job_id:str,user=Depends(auth)):
 with Session.begin() as db:
  j=db.get(Job,job_id)
  if not j or j.user_id!=user:raise HTTPException(404)
  if j.status!='completed':raise HTTPException(409,'Vídeo ainda não concluído')
  j.final_approved_at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc)
  return {'approved':True,'download_url':f'/v1/jobs/{job_id}/download'}
@app.get('/v1/jobs/{job_id}/preview')
def preview(job_id:str,user=Depends(auth)):
 from .media_pipeline import signed_video_url
 with Session() as db:
  j=db.get(Job,job_id)
  if not j or j.user_id!=user or j.status!='completed' or not j.video_path:raise HTTPException(404)
  return {'url':signed_video_url(j.video_path,300)}
@app.get('/v1/jobs/{job_id}/download')
def download(job_id:str,user=Depends(auth)):
 from .media_pipeline import signed_video_url
 with Session() as db:
  j=db.get(Job,job_id)
  if not j or j.user_id!=user or j.status!='completed' or not j.video_path:raise HTTPException(404)
  if not j.final_approved_at:raise HTTPException(403,'Aprovação final obrigatória')
  return {'url':signed_video_url(j.video_path,900)}
@app.get('/v1/credits')
def credits(user=Depends(auth)):
 with Session.begin() as db:
  u=ensure_user(db,user);return {'balance':u.balance,'ledger':[{'kind':x.kind,'amount':x.amount,'job_id':x.job_id} for x in db.query(Ledger).filter_by(user_id=user).all()]}
