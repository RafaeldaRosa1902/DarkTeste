"""Production media adapters. No fabricated media or fallback in production."""
import os, json, pathlib, subprocess, tempfile, math, random, requests
from urllib.parse import urlparse
from .domain import normalize

def require(name):
 value=os.getenv(name)
 if not value: raise RuntimeError(f'{name} não configurada')
 return value

def tts(text, target, voice='alloy'):
 from openai import OpenAI
 client=OpenAI(api_key=require('OPENAI_API_KEY'))
 with client.audio.speech.with_streaming_response.create(model=os.getenv('TTS_MODEL','tts-1'),voice=voice,input=text,response_format='mp3') as response:
  response.stream_to_file(str(target))
 return target

def transcribe(audio):
 from openai import OpenAI
 with open(audio,'rb') as handle:
  result=OpenAI(api_key=require('OPENAI_API_KEY')).audio.transcriptions.create(model='whisper-1',file=handle,response_format='verbose_json',timestamp_granularities=['word'])
 words=[]
 for w in result.words or []:
  start=getattr(w,'start',None) if not isinstance(w,dict) else w.get('start')
  end=getattr(w,'end',None) if not isinstance(w,dict) else w.get('end')
  word=getattr(w,'word',None) if not isinstance(w,dict) else w.get('word')
  if start is not None and end is not None and word:
   words.append({'word':word.strip(),'startMs':round(start*1000),'endMs':round(end*1000)})
 if not words: raise RuntimeError('Whisper não retornou timestamps por palavra')
 return words

def duration(path):
 cmd=['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)]
 return float(subprocess.check_output(cmd,text=True,timeout=30).strip())

def pexels_clips(query, count, folder, used_ids=None):
 key=require('PEXELS_API_KEY'); used=set(used_ids or []); result=[]
 r=requests.get('https://api.pexels.com/videos/search',headers={'Authorization':key},params={'query':query,'per_page':min(80,max(count*8,20)),'orientation':'portrait'},timeout=30)
 r.raise_for_status()
 for video in r.json().get('videos',[]):
  vid=video['id']
  if vid in used:continue
  files=[x for x in video.get('video_files',[]) if x.get('link') and x.get('file_type')=='video/mp4']
  if not files:continue
  files.sort(key=lambda x:(abs((x.get('width') or 1080)-1080)+abs((x.get('height') or 1920)-1920)))
  link=files[0]['link']; dest=folder/f'pexels-{vid}.mp4'
  with requests.get(link,stream=True,timeout=90) as stream:
   stream.raise_for_status()
   with dest.open('wb') as f:
    for chunk in stream.iter_content(1024*1024):f.write(chunk)
  used.add(vid)
  result.append({'path':dest,'provider':'pexels','provider_id':vid,'author':video.get('user',{}).get('name'),'source_url':video.get('url'),'license_url':'https://www.pexels.com/license/'})
  if len(result)>=count:break
 if len(result)<count:raise RuntimeError(f'Pexels retornou apenas {len(result)} de {count} clipes únicos')
 return result

def render_remotion(manifest, output, workdir):
 root=pathlib.Path(os.getenv('REMOTION_DIR','/srv/remotion'))
 if not (root/'package.json').exists():raise RuntimeError('Projeto Remotion ausente no worker')
 props=workdir/'manifest.json';props.write_text(json.dumps(manifest,ensure_ascii=False))
 cmd=['pnpm','exec','remotion','render','src/index.ts','VerticalVideo',str(output),'--props',str(props),'--codec','h264','--concurrency','1']
 subprocess.run(cmd,cwd=root,check=True,timeout=int(os.getenv('RENDER_TIMEOUT_SECONDS','1200')))
 if not output.exists() or output.stat().st_size<1024:raise RuntimeError('Remotion não gerou MP4 válido')
 return output

def upload_private(path, job_id):
 from supabase import create_client
 client=create_client(require('SUPABASE_URL'),require('SUPABASE_SERVICE_ROLE_KEY'))
 bucket=os.getenv('SUPABASE_VIDEO_BUCKET','videos'); key=f'{job_id}/final.mp4'
 with open(path,'rb') as f: client.storage.from_(bucket).upload(key,f.read(),{'content-type':'video/mp4','upsert':'true'})
 return key

def signed_video_url(key,seconds=900):
 from supabase import create_client
 client=create_client(require('SUPABASE_URL'),require('SUPABASE_SERVICE_ROLE_KEY'))
 result=client.storage.from_(os.getenv('SUPABASE_VIDEO_BUCKET','videos')).create_signed_url(key,seconds)
 return result.get('signedURL') or result.get('signedUrl')

def make_manifest(audio,words,clips,fps,workdir):
 seconds=duration(audio);frames=max(1,math.ceil(seconds*fps));segment=math.ceil(frames/len(clips))
 scenes=[]
 for i,clip in enumerate(clips):
  # Local files are staged in Remotion public; use staticFile-compatible URLs.
  scenes.append({'startFrame':i*segment,'endFrame':min(frames,(i+1)*segment),'clipUrl':f'/assets/{clip["path"].name}'})
 return {'fps':fps,'durationFrames':frames,'scenes':scenes,'captions':words,'narrationUrl':'/assets/narration.mp3','musicVolume':0.08}
