import os,uuid
from sqlalchemy.exc import IntegrityError
from .db import Session,User,Ledger,Job,Idempotency

def uid():return str(uuid.uuid4())
def ensure_user(db,user_id):
 u=db.get(User,user_id)
 if not u:
  u=User(id=user_id,balance=100);db.add(u);db.flush()
 return u

def create_job(user_id,script_id,key,fps=30):
 # SQLite local serialization is limited; production uses Supabase RPC with row locking.
 with Session.begin() as db:
  existing=db.get(Idempotency,key)
  if existing:
   if existing.user_id!=user_id:raise ValueError('Chave de idempotência pertence a outro usuário')
   return existing.resource_id,False
  user=ensure_user(db,user_id);cost=10+(5 if fps==60 else 0)
  if user.balance<cost:raise ValueError('Créditos insuficientes')
  job_id=uid();user.balance-=cost
  db.add(Job(id=job_id,user_id=user_id,script_id=script_id,cost=cost,fps=fps))
  db.add(Ledger(id=uid(),user_id=user_id,job_id=job_id,kind='debit',amount=-cost,key='debit:'+job_id))
  db.add(Idempotency(key=key,user_id=user_id,resource_id=job_id))
  return job_id,True

def refund_once(job_id,error):
 with Session.begin() as db:
  job=db.get(Job,job_id)
  if not job:return False
  if job.status=='completed':return False
  job.status='failed';job.error=str(error)[:1000]
  if db.query(Ledger).filter_by(key='refund:'+job_id).first():return False
  ensure_user(db,job.user_id).balance+=job.cost
  db.add(Ledger(id=uid(),user_id=job.user_id,job_id=job.id,kind='refund',amount=job.cost,key='refund:'+job_id))
  return True
