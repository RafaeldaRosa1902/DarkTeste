import os, pathlib, logging, shutil, tempfile, json
from celery import Celery
from sqlalchemy import update
from .db import Session,Job,Script
from .services import refund_once
from .domain import TRANSITIONS
from . import media_pipeline as media
celery_app=Celery('darkfactory',broker=os.getenv('REDIS_URL','redis://localhost:6379/0'),backend=os.getenv('REDIS_URL','redis://localhost:6379/0'))
celery_app.conf.update(task_routes={'app.worker.produce':{'queue':'production'}},worker_prefetch_multiplier=1,task_acks_late=True)

def transition(job_id,to):
 with Session.begin() as db:
  job=db.get(Job,job_id)
  if not job or to not in TRANSITIONS.get(job.status,set()):return False
  # Atomic compare-and-set prevents two redelivered tasks from starting.
  old=job.status
  return db.execute(update(Job).where(Job.id==job_id,Job.status==old).values(status=to)).rowcount==1

@celery_app.task(name='app.worker.produce',acks_late=True,reject_on_worker_lost=True)
def produce(job_id):
 if not transition(job_id,'tts'):return {'skipped':True}
 try:
  with Session() as db:
   job=db.get(Job,job_id);script=db.get(Script,job.script_id)
   text=script.body;fps=job.fps
  root=pathlib.Path(os.getenv('RENDER_DIR','/data/renders'))/job_id
  root.mkdir(parents=True,exist_ok=True)
  if os.getenv('DEMO_MODE','false').lower()=='true':
   raise RuntimeError('DEMO_MODE não é permitido para renderização real')
  audio=media.tts(text,root/'narration.mp3')
  if not transition(job_id,'transcribing'):return
  words=media.transcribe(audio)
  if not transition(job_id,'fetching_media'):return
  count=max(2,min(10,round(media.duration(audio)/6)))
  clips=media.pexels_clips(os.getenv('PEXELS_SEARCH_QUERY','cinematic nature'),count,root)
  if not transition(job_id,'rendering'):return
  # Remotion serves assets from its public directory during render.
  public=pathlib.Path(os.getenv('REMOTION_DIR','/srv/remotion'))/'public'/'assets'
  public.mkdir(parents=True,exist_ok=True)
  # One render per worker/container, and unique filenames for each job.
  for asset in [audio]+[c['path'] for c in clips]:shutil.copy2(asset,public/asset.name)
  manifest=media.make_manifest(audio,words,clips,fps,root)
  out=root/'final.mp4';media.render_remotion(manifest,out,root)
  if not transition(job_id,'uploading'):return
  storage_key=media.upload_private(out,job_id)
  with Session.begin() as db:
   j=db.get(Job,job_id)
   if j.status!='uploading':return
   j.video_path=storage_key;j.status='completed'
  (root/'attribution.json').write_text(json.dumps([{k:v for k,v in c.items() if k!='path'} for c in clips],ensure_ascii=False))
  return {'storage_key':storage_key}
 except Exception as exc:
  logging.exception('Falha de produção %s',job_id)
  refund_once(job_id,str(exc))
  raise
