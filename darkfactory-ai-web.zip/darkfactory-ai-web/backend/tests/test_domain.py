from app.domain import originality,group_captions
from app.services import create_job,refund_once
from app.db import Session,User,Ledger
import uuid
def test_originality():
 assert originality('um dois tres quatro cinco seis',['um dois tres quatro cinco seis'])==0
 assert originality('planetas giram em orbitas muito distantes',['maçãs caem no chão de repente'])==1
def test_caption_grouping():
 assert [len(x) for x in group_captions(list(range(9)),4)]==[4,4,1]
def test_refund_once():
 user=str(uuid.uuid4());key=str(uuid.uuid4());job,created=create_job(user,'script',key)
 job2,created2=create_job(user,'script',key)
 assert job==job2 and not created2
 assert refund_once(job,'falha')
 assert not refund_once(job,'falha novamente')
 with Session() as db:
  assert db.get(User,user).balance==100
  assert db.query(Ledger).filter_by(job_id=job).count()==2
