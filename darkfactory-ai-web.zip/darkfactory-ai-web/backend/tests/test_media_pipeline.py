from app.media_pipeline import make_manifest
from pathlib import Path

def test_manifest_timing(monkeypatch,tmp_path):
 monkeypatch.setattr('app.media_pipeline.duration',lambda _:11)
 clips=[{'path':Path('one.mp4')},{'path':Path('two.mp4')}]
 result=make_manifest(Path('narration.mp3'),[{'word':'oi','startMs':0,'endMs':250}],clips,30,tmp_path)
 assert result['durationFrames']==330
 assert result['scenes'][0]['startFrame']==0
 assert result['scenes'][-1]['endFrame']==330
