import os
os.environ['DEMO_MODE']='true'
from fastapi.testclient import TestClient
from app.main import app

def test_script_route_not_shadowed():
    paths=[r.path for r in app.routes if hasattr(r,'path')]
    assert '/v1/ideas/{idea_id}/script' in paths
    assert '/v1/ideas/{idea_id}/{decision}' not in paths
    c=TestClient(app)
    ch=c.post('/v1/channels',json={'name':'Teste','niche':'curiosidades','template':'facts'}).json()['id']
    idea=c.post(f'/v1/channels/{ch}/research',json={'signals':[]}).json()[0]['id']
    assert c.post(f'/v1/ideas/{idea}/approve').status_code==200
    r=c.post(f'/v1/ideas/{idea}/script')
    assert r.status_code==200,r.text
