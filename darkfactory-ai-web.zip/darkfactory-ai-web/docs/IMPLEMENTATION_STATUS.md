# Estado das entregas 4–7

| Componente | Estado |
|---|---|
| FastAPI: canais, pesquisa, ideias, roteiro, aprovações, jobs, créditos | Implementação local demonstrativa |
| Claude: roteiro | Integração básica quando configurado |
| YouTube Data API | Pesquisa de títulos como sinais, quando configurada |
| Originalidade 4-gramas | Implementado; necessita corpus de fontes reais |
| Ledger e estorno idempotente | Implementado em SQLite local; migrar para RPC Postgres |
| Celery/Redis | Implementado, worker concorrência 1 |
| TTS/Whisper/Pexels reais | **Não implementados no pipeline** |
| Render do worker | Vídeo demonstrativo FFmpeg; Remotion separado |
| Remotion | Composição funcional básica, legendas por palavra, música fade |
| Supabase | SQL RLS base; não é migração integral da Entrega 2 |
| Frontend | Tela única de fluxo demonstrativo, sem login Supabase |
| Testes | Unitários iniciais, sem E2E real |
| Docker Compose | Arquivos fornecidos, execução não homologada |

## Bloqueios para produção
1. Implementar JWT Supabase moderno (JWKS/algoritmo do projeto) e sessão no frontend; remover X-Demo-User.
2. Aplicar schema completo da Entrega 2 e substituir SQLite por repositórios/RPC Supabase, com transações e locks.
3. Integrar TTS, Whisper, Pexels e invocação Remotion no worker com arquivos temporários seguros.
4. Implementar storage privado com URLs assinadas, aprovação final persistida e restrição de download à aprovação.
5. Implementar políticas de quota e concorrência por plano, antifraude, revisão humana, logs, métricas e alertas.
6. Integrar políticas de conteúdo sensível, disclosure de mídia sintética, metadados de licença e moderação.
7. Testar build, pipeline E2E, falhas forçadas, redelivery, concorrência e segurança.
