# Integrações de produção: estado e configuração

## Implementado no código
- TTS OpenAI gera MP3; Whisper devolve timestamps por palavra.
- Pexels pesquisa e baixa clipes únicos por render, registra autor, URL e licença em attribution.json.
- Remotion renderiza manifesto 9:16 e o worker envia MP4 para bucket privado Supabase.
- Endpoint de preview devolve URL assinada de 5 minutos; download exige aprovação final persistida e devolve URL assinada de 15 minutos.
- JWT é validado com JWKS do Supabase; modo demo não deve ser habilitado em produção.
- Migração 0002 contém RPC transacional de débito/estorno com bloqueio de saldo e permissões para service_role.

## Bloqueios importantes antes de produção
1. **Persistência**: backend ainda usa modelos SQLAlchemy legados (`users`, `ledger`, `idempotency`) diferentes das tabelas Supabase (`credit_accounts`, `credit_ledger`, `idempotency_keys`). É obrigatório substituir a camada de repositórios e fazer `create_job`/`refund_once` chamarem as RPCs da migração 0002; não há compatibilidade automática. Não execute a API legada contra o schema Supabase esperando que funcione.
2. **Migrações**: executar e validar 0001 e 0002 em projeto Supabase real. Revisar as funções SECURITY DEFINER, os grants e os RLS antes de ativar usuários.
3. **Autenticação frontend**: o campo manual de JWT é somente uma ferramenta de integração. Substituir por Supabase Auth com login/logout, renovação de sessão e armazenamento seguro.
4. **Originalidade**: a API compara roteiro apenas com título e ângulo, não com transcrições reais de fontes; exigir fontes recuperadas, verificação de sobreposição e referências.
5. **Media**: pesquisa Pexels usa consulta genérica configurada; deve ser derivada de cenas do roteiro e os registros de licenças persistidos no banco, não apenas em JSON local.
6. **Resiliência**: falta reconciliador para jobs órfãos após morte de worker, limpeza de arquivos públicos temporários, quotas por plano, teste concorrente de crédito e retries seletivos.
7. **Frontend**: faltam player embutido, gestão de sessões e painel de créditos completo.
8. **Custos e conformidade**: definir políticas de retenção, moderação, marcação de conteúdo sintético e consentimento de provedores.

## Dependências e credenciais
Configure `OPENAI_API_KEY`, `PEXELS_API_KEY`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `DATABASE_URL`, `REDIS_URL` e opcionalmente `ANTHROPIC_API_KEY`, `YOUTUBE_API_KEY`. Nunca coloque service role ou API keys no navegador.

## Testes
`cd backend && pytest -q` (instalar `backend/requirements.txt`). Testes não cobrem rede, render completo, banco Supabase ou autenticação real.
