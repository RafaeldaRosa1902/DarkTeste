# DarkFactory AI: hospedagem web (demonstração)

## Implantação no Render
1. Crie uma conta em https://render.com e um repositório privado no GitHub.
2. Envie **o conteúdo desta pasta** ao repositório (incluindo `render.yaml`). Nunca envie `.env` ou chaves reais.
3. No Render: **New > Blueprint**, conecte o repositório e revise os serviços e os custos.
4. Confirme o Blueprint. O Render provisionará PostgreSQL, Redis, API, worker e frontend.
5. Abra o endereço HTTPS gerado para `darkfactory-web`. A rota `/api/health` deve retornar `{"ok":true}`.

## O que funciona no modo demo
- Criação de canais, sete ideias, aprovação, roteiro demonstrativo, edição e aprovação do roteiro.
- O bug 422 anterior foi corrigido: `/v1/ideas/{idea_id}/script` não é mais interceptado pela rota dinâmica de decisões.
- A renderização real permanece desabilitada no modo demo; tentativas de render são marcadas como falha e estornadas pelo worker.

## Limitações e segurança
- `DEMO_MODE=true` **não oferece autenticação real**. O identificador por navegador evita misturar dados casualmente, mas pode ser falsificado. **Não coloque dados privados e não use esta configuração como SaaS público.**
- A estrutura de banco desta edição é criada por SQLAlchemy, não é a migração definitiva Supabase com RLS.
- Para uso comercial, substituir modo demo por Supabase Auth com login, banco com RLS/RPC, limites por usuário, pagamentos e renderização real em worker com Chromium/Remotion e Storage privado.
- O Render pode cobrar por banco persistente, Redis e worker. Confirme preços antes de criar os serviços.
- Não há um endereço público ativo até você implantar o repositório na sua conta.
