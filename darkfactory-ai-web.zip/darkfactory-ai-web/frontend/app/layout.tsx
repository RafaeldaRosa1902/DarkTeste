import React from 'react';
export const metadata={title:'DarkFactory AI',description:'Fábrica de vídeos verticais com aprovação humana'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body style={{fontFamily:'system-ui',background:'#0e1423',color:'#eef3ff',margin:0}}>{children}</body></html>}
