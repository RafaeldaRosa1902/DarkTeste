/** @type {import('next').NextConfig} */
const nextConfig={
  async rewrites(){return [{source:'/api/:path*',destination:`${(process.env.API_INTERNAL_URL||'http://api:8000').startsWith('http')?(process.env.API_INTERNAL_URL||'http://api:8000'):'http://'+process.env.API_INTERNAL_URL}/:path*`}]}
};
export default nextConfig;
