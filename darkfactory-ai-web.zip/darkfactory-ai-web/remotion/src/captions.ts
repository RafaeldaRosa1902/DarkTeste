export type Word={word:string;startMs:number;endMs:number};
export function groupWords(words:Word[],max=4){const out:Word[][]=[];for(let i=0;i<words.length;i+=max)out.push(words.slice(i,i+max));return out}
export function activeWord(words:Word[],ms:number){return words.findIndex(w=>ms>=w.startMs&&ms<w.endMs)}
