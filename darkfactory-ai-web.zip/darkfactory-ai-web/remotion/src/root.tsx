import React from 'react';import {Composition} from 'remotion';import {VerticalVideo,VideoProps} from './video';
const defaults:VideoProps={fps:30,durationFrames:150,scenes:[],captions:[{word:'DarkFactory',startMs:0,endMs:2000}],musicVolume:0.08};
export const Root=()=> <Composition id="VerticalVideo" component={VerticalVideo} width={1080} height={1920} fps={30} durationInFrames={150} defaultProps={defaults} calculateMetadata={({props})=>({durationInFrames:props.durationFrames,fps:props.fps})}/>;
