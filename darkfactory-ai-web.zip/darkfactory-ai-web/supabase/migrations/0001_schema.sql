-- Base de produção mínima, com políticas RLS. Complementar com as funções
-- transacionais debit_credits/refund_credits/create_render_job da Entrega 2.
create extension if not exists pgcrypto;
create table if not exists public.channels(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id),name text not null,niche text not null,language text not null default 'pt-BR',region text not null default 'BR',template text not null);
create table if not exists public.ideas(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id),channel_id uuid not null references public.channels(id),title text not null,angle text not null,status text not null default 'pending');
create table if not exists public.scripts(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id),idea_id uuid not null references public.ideas(id),body text not null,status text not null default 'draft',originality numeric not null default 1);
create table if not exists public.jobs(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id),script_id uuid not null references public.scripts(id),status text not null default 'queued',error text,video_path text,cost integer not null,final_approved_at timestamptz);
create table if not exists public.credit_accounts(user_id uuid primary key references auth.users(id),balance integer not null default 0 check(balance>=0));
create table if not exists public.credit_ledger(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id),job_id uuid references public.jobs(id),kind text not null,amount integer not null,idempotency_key text not null unique);
create table if not exists public.idempotency_keys(key text primary key,user_id uuid not null references auth.users(id),resource_id uuid not null);
alter table public.channels enable row level security;alter table public.ideas enable row level security;alter table public.scripts enable row level security;alter table public.jobs enable row level security;alter table public.credit_accounts enable row level security;alter table public.credit_ledger enable row level security;
create policy channels_read on public.channels for select to authenticated using(user_id=auth.uid());
create policy ideas_read on public.ideas for select to authenticated using(user_id=auth.uid());
create policy scripts_read on public.scripts for select to authenticated using(user_id=auth.uid());
create policy jobs_read on public.jobs for select to authenticated using(user_id=auth.uid());
create policy accounts_read on public.credit_accounts for select to authenticated using(user_id=auth.uid());
create policy ledger_read on public.credit_ledger for select to authenticated using(user_id=auth.uid());
