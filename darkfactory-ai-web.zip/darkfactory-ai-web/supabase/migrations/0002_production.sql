-- Apply after 0001_schema.sql. Run with Supabase CLI, not SQLAlchemy create_all.
create unique index if not exists credit_ledger_once_per_job_kind on public.credit_ledger(job_id,kind) where job_id is not null;
alter table public.jobs add column if not exists fps integer not null default 30 check (fps in (30,60));
alter table public.jobs add column if not exists final_approved_at timestamptz;
create or replace function public.create_render_job(p_user uuid,p_script uuid,p_key text,p_fps integer default 30)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_job uuid;v_cost integer;v_balance integer;
begin
 if p_fps not in (30,60) then raise exception 'FPS inválido';end if;
 if not exists(select 1 from public.scripts where id=p_script and user_id=p_user and status='approved') then raise exception 'Roteiro não aprovado';end if;
 select resource_id into v_job from public.idempotency_keys where key=p_key and user_id=p_user;
 if v_job is not null then return v_job;end if;
 v_cost:=10+case when p_fps=60 then 5 else 0 end;
 select balance into v_balance from public.credit_accounts where user_id=p_user for update;
 if v_balance is null or v_balance<v_cost then raise exception 'Créditos insuficientes';end if;
 select resource_id into v_job from public.idempotency_keys where key=p_key and user_id=p_user;
 if v_job is not null then return v_job;end if;
 insert into public.jobs(user_id,script_id,status,cost,fps) values(p_user,p_script,'queued',v_cost,p_fps) returning id into v_job;
 update public.credit_accounts set balance=balance-v_cost where user_id=p_user;
 insert into public.credit_ledger(user_id,job_id,kind,amount,idempotency_key) values(p_user,v_job,'debit',-v_cost,'debit:'||v_job);
 insert into public.idempotency_keys(key,user_id,resource_id) values(p_key,p_user,v_job);
 return v_job;
end $$;
create or replace function public.fail_job_and_refund(p_job uuid,p_error text)
returns boolean language plpgsql security definer set search_path = '' as $$
declare v_user uuid;v_cost integer;v_status text;
begin
 select user_id,cost,status into v_user,v_cost,v_status from public.jobs where id=p_job for update;
 if v_user is null or v_status in ('completed','cancelled') then return false;end if;
 update public.jobs set status='failed',error=left(p_error,1000) where id=p_job;
 if exists(select 1 from public.credit_ledger where job_id=p_job and kind='refund') then return false;end if;
 insert into public.credit_ledger(user_id,job_id,kind,amount,idempotency_key) values(v_user,p_job,'refund',v_cost,'refund:'||p_job);
 update public.credit_accounts set balance=balance+v_cost where user_id=v_user;
 return true;
end $$;
revoke all on function public.create_render_job(uuid,uuid,text,integer) from public,anon,authenticated;
revoke all on function public.fail_job_and_refund(uuid,text) from public,anon,authenticated;
grant execute on function public.create_render_job(uuid,uuid,text,integer) to service_role;
grant execute on function public.fail_job_and_refund(uuid,text) to service_role;
insert into storage.buckets(id,name,public) values('videos','videos',false) on conflict(id) do update set public=false;
